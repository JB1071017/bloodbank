<?php
include("connection.php");

//creating a query

$stmt = $con->prepare( "SELECT id,name,email,bloodgroup,phnumber,place,age,gender,lastdonated FROM donatej");

//Executting the query

$stmt->execute();

//binding result to the query

$stmt->bind_result($id,$name,$email,$bloodgroup,$phnumber,$place,$age,$gender,$lastdonated);

$p=array();

while($stmt->fetch()){
    $temp=array();
    $temp['id']=$id;
    $temp['name']=$name;
    $temp['email']=$email;
    $temp['bloodgroup']=$bloodgroup;
    $temp['phnumber']=$phnumber;
    $temp['place']=$place;
    $temp['age']=$age;
    $temp['gender']=$gender;
    $temp['lastdonated']=$lastdonated;
   
  
    array_push($p,$temp);

}
echo json_encode($p);