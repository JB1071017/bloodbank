<?php 
include("connection.php");

$name = $_POST["name"];
$email = $_POST["email"];
$bloodgroup = $_POST["bloodgroup"];
$phonenumber = $_POST["phnumber"];
$place = $_POST["place"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$last = $_POST["lastdonated"];

$q = "INSERT INTO donatej (name, email, bloodgroup, phnumber, place, age, gender, lastdonated) 
      VALUES ('$name', '$email', '$bloodgroup', '$phonenumber', '$place', '$age', '$gender', '$last')";

$result = mysqli_query($con, $q);
if ($result) {
    $response["status"] = "1";
    $response["message"] = "Registration successful";
} else {
    $response["status"] = "0";
    $response["message"] = "Registration failed";
}
echo json_encode($response);
?>
