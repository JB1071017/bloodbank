<?php
include("connection.php");

// Retrieve POST data
$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$bloodgroup = $_POST['bloodgroup'];
$phonenumber = $_POST['phonenumber'];
$password = $_POST['password'];

// Prepare an update statement
$query = "UPDATE registerj SET name=?, email=?, bloodgroup=?, phonenumber=?, password=? WHERE id=?";
$stmt = $con->prepare($query);

if ($stmt) {
    // Bind parameters to the prepared statement
    $stmt->bind_param("sssssi", $name, $email, $bloodgroup, $phonenumber, $password, $id);

    // Execute the prepared statement
    if ($stmt->execute()) {
        $response["status"] = "1";
        $response["message"] = "Updation successful";
    } else {
        $response["status"] = "0";
        $response["message"] = "Updation failed";
    }

    // Close the statement
    $stmt->close();
} else {
    $response["status"] = "0";
    $response["message"] = "Failed to prepare the statement";
}

// Close the database connection
$con->close();

// Encode the response as JSON
echo json_encode($response);
?>
