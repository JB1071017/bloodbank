<?php
include("connection.php");

//creating a query

$stmt = $con->prepare( "SELECT id,campname,campplace,campdate,camptime,campphone,campdetails FROM campj");

//Executting the query

$stmt->execute();

//binding result to the query

$stmt->bind_result($id,$name,$place,$date,$time,$phone,$details);

$p=array();

while($stmt->fetch()){
    $temp=array();
    $temp['id']=$id;
    $temp['campname']=$name;
    $temp['campplace']=$place;
    $temp['campdate']=$date;
    $temp['camptime']=$time;
    $temp['campphone']=$phone;
    $temp['campdetails']=$details;

   
  
    array_push($p,$temp);

}
echo json_encode($p);