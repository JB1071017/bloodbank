<?php 
$con=new mysqli("localhost","root","");
$db=mysqli_select_db($con,"bloodbank") or die(mysqli_error($con));
?>








