<?php 
include("connection.php");

$name=$_POST["name"];
$password=$_POST["password"];
$query="SELECT * FROM `registerj` WHERE name='$name' && password='$password'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
if(mysqli_num_rows($result)>0)
{
    $response["status"]="1";
    $response["message"]="Login Successful";
    $response["id"]=$row[0];
    $response["name"]=$row[1];
    $response["email"]=$row[2];
    $response["bloodgroup"]=$row[3];
    $response["phonenumber"]=$row[4];
    $response["password"]=$row[05];
  

}
else
{
    $response["status"]="0";
    $response["message"]="Login failed";
    $response["id"]="";
    $response["name"]="";
    $response["email"]="";
    $response["bloodgroup"]="";
    $response["phonenumber"]="";
    $response["password"]="";
  
}
echo json_encode($response);
?>
