<?php
include("connection.php");
$name=$_POST['name'];
$dob=$_POST['dob'];
$phonenumber=$_POST['phonenumber'];
$addnotes=$_POST['addnotes'];


$originalImgName=$_FILES['filename']['name'];
$tempName=$_FILES['filename']['tmp_name'];
$folder="uploads/";

if(move_uploaded_file($tempName,$folder.$originalImgName)){
   // $query="insert into uploadmedicalrecords set medicalreports='$originalImgName' where id='$userid',";

   $query="insert into uploadfarj(name,dob,phonenumber,addnotes,image) 
values('$name','$dob','$phonenumber','$addnotes','$originalImgName')";

     if(mysqli_query($con,$query)){
   $response['status']="1";
   $response['message']="file uploaded successfully";  

}
else{
    $response['status']="0";
    $response['message']="Data insertion failed";
}
}
else{
    $response['status']="0";
    $response['message']="File moving failed";
}
echo json_encode($response);
?>






<!-- <?php
include("connection.php");
$name=$_POST['name'];
$dob=$_POST['dob'];
$phonenumber=$_POST['phonenumber'];
$addnotes=$_POST['addnotes'];
// $bn=$_POST['builder_name'];
// $uid=$_POST['user_id'];
// $una=$_POST['user_name'];
// $uphn=$_POST['user_phn'];

$originalImgName=$_FILES['filename']['name'];
$tempName=$_FILES['filename']['tmp_name'];
$folder="upload/";

if(move_uploaded_file($tempName,$folder.$originalImgName)){
    $query="insert into pancreasdonationform(name,dob,phonenumber,addnotes,image)
    values('$name','$dob','$phonenumber','$addnotes','$originalImgName')";
     if(mysqli_query($con,$query)){
   $response['status']="1";
   $response['message']="file uploaded successfully";  

}
else{
    $response['status']="0";
    $response['message']="Data insertion failed";
}
}
else{
    $response['status']="0";
    $response['message']="File moving failed";
}
echo json_encode($response);
?> -->

