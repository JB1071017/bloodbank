<?php 
include("connection.php");

$name =$_POST["name"];
$email =$_POST["email"];
$bloodgroup  =$_POST["bloodgroup"];
$phonenumber =$_POST["phonenumber"];
$password =$_POST["password"];


$q ="INSERT INTO registerj (name,email,bloodgroup,phonenumber,password) VALUES ('$name','$email','$bloodgroup','$phonenumber','$password')";

$result=mysqli_query($con,$q);
if($result){
    $response["status"]="1";
    $response["message"]=" Registration successful";
}
else{
    $response["status"]="0";
    $response["message"]="Registration failed";
}
echo json_encode($response);
?>
