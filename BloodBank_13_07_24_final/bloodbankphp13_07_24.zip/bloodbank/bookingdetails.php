<?php
include ("connection.php");

$phonenumber=$_POST['phonenumber'];

$stmt = $con->prepare("SELECT  id,campname,name,phonenumber FROM campbooking  WHERE phonenumber='$phonenumber'");

   $stmt->execute();
    
    $stmt->bind_result($id,$name,$campname,$phonenumber);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['name']=$name;
        $temp['campname']=$campname;
        $temp['phonenumber']=$phonenumber;

       
        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>
