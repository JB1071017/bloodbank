<?php
include("connection.php");
$cname=$_POST['campname'];
$name=$_POST['name'];
$phonenumber=$_POST['phonenumber'];



$query="insert into campbooking(campname,name,phonenumber)
values('$cname','$name','$phonenumber')";
$result=mysqli_query($con,$query);



if($result)
{
$response["status"]="1";
$response["message"]="upload successfull";
}
else
{
    $response["status"]="0";
    $response["message"]="upload failed";
}
echo json_encode($response);
?>

