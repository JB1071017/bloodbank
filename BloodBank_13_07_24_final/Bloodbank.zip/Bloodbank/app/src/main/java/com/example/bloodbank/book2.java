package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class book2 extends AppCompatActivity {


    CardView c1,c2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book2);

        c1 = findViewById(R.id.bookcamp1);
        c2 = findViewById(R.id.seedetails);




        c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent nnn=new Intent(book2.this,campactivity.class);
                startActivity(nnn);
            }
        });

        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent nkn=new Intent(book2.this,camp25.class);
                startActivity(nkn);
            }
        });
    }
}