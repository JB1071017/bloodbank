package com.example.bloodbank;

public class donatelistmodel {
    String id,name,email,bloodgroup,phnumber,place,age,gender,lastdonated;

    public donatelistmodel(String id, String name, String email, String bloodgroup, String phnumber, String place, String age, String gender, String lastdonated) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.bloodgroup = bloodgroup;
        this.phnumber = phnumber;
        this.place = place;
        this.age = age;
        this.gender = gender;
        this.lastdonated = lastdonated;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public String getPhnumber() {
        return phnumber;
    }

    public String getPlace() {
        return place;
    }

    public String getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getLastdonated() {
        return lastdonated;
    }
}
