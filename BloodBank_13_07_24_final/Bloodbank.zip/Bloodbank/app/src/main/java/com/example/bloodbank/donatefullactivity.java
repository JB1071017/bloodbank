package com.example.bloodbank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.Manifest;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



public class donatefullactivity extends AppCompatActivity {
    TextView name,email,bloodgroup,phn,place,age,gender,last;

    String name3,email3,bloodgroup3,phn3,place3,age3,gender3,last3;
    Button b;
    ImageView img;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donatefullactivity);
        name = findViewById(R.id.name5);
        email=findViewById(R.id.email3);
        bloodgroup = findViewById(R.id.bloodgroup4);
        phn=findViewById(R.id.ph);
        place = findViewById(R.id.place4);
        age=findViewById(R.id.age5);
        gender = findViewById(R.id.gender5);
        last=findViewById(R.id.doante4);
        img=findViewById(R.id.whatsapp);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chatw();
            }

            private void chatw() {
                Uri mUri = Uri.parse("smsto:" +phn3 );
                Intent mIntent = new Intent(Intent.ACTION_SENDTO, mUri);
                mIntent.setPackage("com.whatsapp");
                mIntent.putExtra("sms_body", "The text goes here");
                mIntent.putExtra("chat", true);
                startActivity(Intent.createChooser(mIntent, ""));
            }

        });

//        time = findViewById(R.id.ct);
//        contactnumber = findViewById(R.id.cnumber);
//        campdetails = findViewById(R.id.cc);


        b = findViewById(R.id.button1);


        Intent intent = getIntent();
        name3 = intent.getStringExtra("name");
        name.setText("Name :"+  name3);

        email3 = intent.getStringExtra("email");
        email.setText("Phone:"+email3);

        bloodgroup3 = intent.getStringExtra("bloodgroup");
        bloodgroup.setText("Name :"+  bloodgroup3);

        phn3 = intent.getStringExtra("phnumber");
        phn.setText("Phone:"+phn3);

        place3 = intent.getStringExtra("place");
        place.setText("Name :"+  place3);

        age3 = intent.getStringExtra("age");
        age.setText("Phone:"+age3);

        gender3 = intent.getStringExtra("gender");
        gender.setText("Name :"+  gender3);

        last3 = intent.getStringExtra("lastdonated");
        last.setText("Phone:"+last3);
//
//        cend = intent.getStringExtra("addnotes");
//        enddate.setText(cend);
//
//        civ1 = intent.getStringExtra("phonenumber");
//        phn.setText(civ1);
//
//        ctime = intent.getStringExtra("time");
//        time.setText("time  :" + ctime);
//
//        ccontact = intent.getStringExtra("contactnumber");
//        contactnumber.setText("contactnumber  :" + ccontact);
//
//        ccamp = intent.getStringExtra("campdetails");
//        campdetails.setText("campdetails  :" + ccamp);

//        b.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent in=new Intent(Cancercampfulldetails.this,Donatepeoples.class);
//                startActivity(in);
//            }
//        });


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
            }
        });
    }

    private void check() {
        if (ContextCompat.checkSelfPermission(donatefullactivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(donatefullactivity.this, new String[] { Manifest.permission.SEND_SMS }, 1);
        }
        else {
            sendOTP();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendOTP();
            } else {
                Toast.makeText(donatefullactivity.this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendOTP() {
        String msg = "Blood urgentely required. Your donation can make a life saving difference!Please make a contact on this  number.." ;

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phn3, null, msg, null, null);

        Toast.makeText(donatefullactivity.this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
    }
}

