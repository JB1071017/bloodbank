package com.example.bloodbank;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

//import com.mashood.kaudisorders.R;
//import com.mashood.kaudisorders.disorder.DisorderListActivity;
//import com.squareup.picasso.Picasso;

//import com.example.wecan.ui.dashboard.DashboardFragment;

import java.util.ArrayList;

public class donatelistadpter extends RecyclerView.Adapter<donatelistadpter.MyViewHolder> {


    private LayoutInflater inflater;
    private ArrayList<donatelistmodel> dataModelArrayList;
    private Context c;


    public donatelistadpter(Context ctx, ArrayList<donatelistmodel> dataModelArrayList) {

        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.donatelist, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.name.setText("Name:"+dataModelArrayList.get(position).getName());
        holder.bloodgroup.setText(" BloodGroup:  "+dataModelArrayList.get(position).getBloodgroup());
        holder.phonenumber.setText("Phonenumber:  "+dataModelArrayList.get(position).getPhnumber());
//        holder.place.setText("Place:  "+dataModelArrayList.get(position).getPlace());
//        holder.age.setText("Age:  "+dataModelArrayList.get(position).getEmail());
//        holder.gender.setText("Gender:  "+dataModelArrayList.get(position).getGender());
//        holder.lastdonated.setText("LastDonated:  "+dataModelArrayList.get(position).getLastdonated());



        //call function
        holder.phonenumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(dataModelArrayList.get(position).getPhnumber());
            }

            private void call(String contactnumber) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" +contactnumber));
                c.startActivity(intent);
            }
        });

        //button click cheyumbo data kittan
//
//        holder.edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, RequestformforAshaWorker.class);
//
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
//
//        });


        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(c, donatefullactivity.class);
                intent.putExtra("name",dataModelArrayList.get(position).getName());
                intent.putExtra("email", dataModelArrayList.get(position).getEmail());
                intent.putExtra("bloodgroup",dataModelArrayList.get(position).getBloodgroup());
                intent.putExtra("phnumber", dataModelArrayList.get(position).getPhnumber());
                intent.putExtra("place", dataModelArrayList.get(position).getPlace());
                intent.putExtra("age",dataModelArrayList.get(position).getAge());
                intent.putExtra("gender",dataModelArrayList.get(position).getGender());
                intent.putExtra("lastdonated",dataModelArrayList.get(position).getLastdonated());

                c.startActivity(intent);

//                        if (!dataModelArrayList.get(position).getImage().equals("")) {
//            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
            }
//
       });

//        holder.edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, Nuraeasharequestform.class);
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//                intent.putExtra("phonenumber", dataModelArrayList.get(position).getPhonenumber());
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
//
//        });


        //sms nte code




//
//      holder.cardView.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View view) {
//               BookingDataModel p = dataModelArrayList.get(position);
//             String crop = p.getBloodgp();
//           //    String img = p.getImage();
//              Intent i = new Intent(c, Bookingdonorslist.class);
//               i.putExtra("crop", crop);
//               c.startActivity(i);
//            }
//       });

    }


    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }


    public void filterList(ArrayList<donatelistmodel> filteredSongs) {
        this.dataModelArrayList = filteredSongs;
        notifyDataSetChanged();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {


        CardView cardView;
        TextView name,bloodgroup,phonenumber,place,age,gender,lastdonated;

//        Button edit;
        String id,cname;


        public MyViewHolder(View itemView) {
            super(itemView);
            cardView=itemView.findViewById(R.id.donatelist);
            name = itemView.findViewById(R.id.name2);
            bloodgroup = itemView.findViewById(R.id.bloodgroup2);
            phonenumber = itemView.findViewById(R.id.phone2);
//            place = itemView.findViewById(R.id.place2);
//            age = itemView.findViewById(R.id.age2);
//            gender = itemView.findViewById(R.id.gender2);
//            lastdonated =itemView.findViewById(R.id.last2);

//            edit.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Intent in=new Intent(c, Doctorsbookingform.class);
//                    in.putExtra("id",id);
//                    in.putExtra("name",cname);
//
//                }
//            });



        }

    }
}


