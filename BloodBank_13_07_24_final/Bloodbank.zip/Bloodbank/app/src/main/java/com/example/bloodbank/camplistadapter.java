package com.example.bloodbank;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

//import com.mashood.kaudisorders.R;
//import com.mashood.kaudisorders.disorder.DisorderListActivity;
//import com.squareup.picasso.Picasso;

//import com.example.wecan.ui.dashboard.DashboardFragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class camplistadapter extends RecyclerView.Adapter<camplistadapter.MyViewHolder> {


    private LayoutInflater inflater;
    private ArrayList<camplistmodel> dataModelArrayList;
    private Context c;



    String url=config.baseurl+"delete.php";

    String status,message;
    public camplistadapter(Context ctx, ArrayList<camplistmodel> dataModelArrayList) {

        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }




    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.camp_list, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.campname.setText("CampName:"+dataModelArrayList.get(position).getCampname());
        holder.name.setText(" Name:  "+dataModelArrayList.get(position).getName());
        holder.phonenumber.setText("Phonenumber:  "+dataModelArrayList.get(position).getPhonenumber());



//        holder.place.setText("Place:  "+dataModelArrayList.get(position).getPlace());
//        holder.age.setText("Age:  "+dataModelArrayList.get(position).getEmail());
//        holder.gender.setText("Gender:  "+dataModelArrayList.get(position).getGender());
//        holder.lastdonated.setText("LastDonated:  "+dataModelArrayList.get(position).getLastdonated());



        //call function
//        holder.phonenumber.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                call(dataModelArrayList.get(position).getPhnumber());
//            }
//
//            private void call(String contactnumber) {
//                Intent intent=new Intent(Intent.ACTION_DIAL);
//                intent.setData(Uri.parse("tel:" +contactnumber));
//                c.startActivity(intent);
//            }
//        });

        //button click cheyumbo data kittan
//
//        holder.edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, RequestformforAshaWorker.class);
//
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
//
//        });


//        holder.cardView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, donatefullactivity.class);
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//                intent.putExtra("email", dataModelArrayList.get(position).getEmail());
//                intent.putExtra("bloodgroup",dataModelArrayList.get(position).getBloodgroup());
//                intent.putExtra("phnumber", dataModelArrayList.get(position).getPhnumber());
//                intent.putExtra("place", dataModelArrayList.get(position).getPlace());
//                intent.putExtra("age",dataModelArrayList.get(position).getAge());
//                intent.putExtra("gender",dataModelArrayList.get(position).getGender());
//                intent.putExtra("lastdonated",dataModelArrayList.get(position).getLastdonated());
//
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
////
//        });

//        holder.edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, Nuraeasharequestform.class);
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//                intent.putExtra("phonenumber", dataModelArrayList.get(position).getPhonenumber());
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
//
//        });


        holder.i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                re();
            }

            private void re() {
                new AlertDialog.Builder(c)
                        .setTitle("Delete")
                        .setMessage("Are you sure you want to Delete this booking?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dele(dataModelArrayList.get(position).getId());

                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent=new Intent(c, campactivity.class);
                                c.startActivity(intent);
                            }
                        })
                        .show();

            }

        });





    }





    private void dele(String id) {
        StringRequest str = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

//                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsnb = new JSONObject(response);
                    status = jsnb.getString("status");
                    message = jsnb.getString("message");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if ("0".equals(status)) {
                    Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(c, " Removed", Toast.LENGTH_SHORT).show();
                    c.startActivity(new Intent(c, Home.class));

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id );


                return params;
            }
        };

        RequestQueue rq = Volley.newRequestQueue(c);
        rq.add(str);


    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }


    public void filterList(ArrayList<camplistmodel> filteredSongs) {
        this.dataModelArrayList = filteredSongs;
        notifyDataSetChanged();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {


//        CardView cardView;
        TextView campname,name,phonenumber;
        ImageView i1;



        //        Button edit;
//        String id,cname;


        public MyViewHolder(View itemView) {
            super(itemView);
//            cardView=itemView.findViewById(R.id.camp_register);
            campname = itemView.findViewById(R.id.textView1);
            name = itemView.findViewById(R.id.textView2);
            phonenumber = itemView.findViewById(R.id.textView3);
            i1 = itemView.findViewById(R.id.delete);
            //            place = itemView.findViewById(R.id.place2);
//            age = itemView.findViewById(R.id.age2);
//            gender = itemView.findViewById(R.id.gender2);
//            lastdonated =itemView.findViewById(R.id.last2);

//            edit.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Intent in=new Intent(c, Doctorsbookingform.class);
//                    in.putExtra("id",id);
//                    in.putExtra("name",cname);
//
//                }
//            });



        }

    }
}


