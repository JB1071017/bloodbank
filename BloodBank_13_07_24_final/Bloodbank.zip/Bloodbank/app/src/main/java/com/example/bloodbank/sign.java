package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class sign extends AppCompatActivity {
    EditText e1,e2;
    Button b1;

    TextView t1,t2;
    String s1,s2,status,message,id,email,bloodgroup,phonenumber;

    String url = config.baseurl+"login.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        e1=findViewById(R.id.username);
        e2=findViewById(R.id.password);
        b1=findViewById(R.id.login1);
        t1=findViewById(R.id.create);
        t2=findViewById(R.id.forget);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(sign.this,Login.class);
                startActivity(in);
            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pn=new Intent(sign.this,Forgotpassword.class);
                startActivity(pn);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });
    }
            private void login() {
                s1=e1.getText().toString();
                s2=e2.getText().toString();

                if(TextUtils.isEmpty(s1))
                {
                    e1.requestFocus();
                    e1.setError("Enter the username");
                    return;
                }
                if(TextUtils.isEmpty(s2))
                {
                    e2.requestFocus();
                    e2.setError("Enter the password");
                    return;
                }
                if(s2.length()<6){
                    e2.setError("Password must be less than 6 charecters");
                    return;
                }
                StringRequest StringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {
                                  Toast.makeText(sign.this, response, Toast.LENGTH_SHORT).show();
                                try {
                                    JSONObject c = new JSONObject(response);
                                    status = c.getString("status");
                                    message = c.getString("message");


                                    id=c.getString("id");
                                    s1=c.getString("name");
                                    email=c.getString("email");
                                    bloodgroup=c.getString("bloodgroup");
                                    phonenumber=c.getString("phonenumber");
                                    s2=c.getString("password");

                                    checklogin();


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //run cheyikkumbo error indo ennu nokkan
                                Toast.makeText(sign.this, String.valueOf(error), Toast.LENGTH_SHORT).show();
                            }

                        }) {

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("name", s1);
                        params.put("password", s2);
                        return params;
                    }


                };

                //string reqt ne execute cheyan aanu requestqueue
                Volley volley =  null;
                RequestQueue requestQueue = volley.newRequestQueue(this);
                requestQueue.add(StringRequest);
            }


    private void checklogin() {
        if (status.equals("0")){
            Toast.makeText(this, "Invalid", Toast.LENGTH_SHORT).show();
        }else {
            new SessionManager(sign.this).createLoginSession(id,s1,email,bloodgroup,phonenumber,s2);
            Toast.makeText(this, "Login successfully", Toast.LENGTH_SHORT).show();
            Intent i =new Intent(sign.this, Home.class);
            startActivity(i);
            finish();
        }

    }
}