package com.example.bloodbank;

public interface config {
    String baseurl="http://192.168.1.56/bloodbank/";
    String imgurl="http://192.168.1.56/bloodbank/uploads";
}

