package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    EditText e1, e2, e3, e4, e5, e6;
    Button b1;
    Spinner spin;
    String bg[]={"Select your blood group","A+","A-","B+","B-","O+","O-","AB+","AB-"};
    TextView t1;

    String se1, se2, se3, se4, se5, se6, status, message;
    String url = config.baseurl + "register.php";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        e1 = findViewById(R.id.sn);
        e2 = findViewById(R.id.se);
        e3 = findViewById(R.id.sp);
        spin=findViewById(R.id.dis);
//        e4 = findViewById(R.id.bg);
        e5 = findViewById(R.id.scp);
        e6 = findViewById(R.id.phone);
        b1 = findViewById(R.id.sign);
        t1 = findViewById(R.id.log);

        ArrayAdapter<String> adpter=new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,bg);
        spin.setAdapter(adpter);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Login.this, sign.class);
                startActivity(in);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });
    }

    private void register() {

        se1 = e1.getText().toString();
        se2 = e2.getText().toString();
        se3 = e3.getText().toString();
        se4=spin.getSelectedItem().toString();
     //   se4 = e4.getText().toString();
        se6 = e6.getText().toString();

        if (TextUtils.isEmpty(se1)) {
            e1.requestFocus();
            e1.setError("Enter the name");
            return;
        }
        if (TextUtils.isEmpty(se2)) {
            e2.requestFocus();
            e2.setError("Enter the email");
            return;
        }
        if (TextUtils.isEmpty(se3)) {
            e3.requestFocus();
            e3.setError("Enter the password");
            return;
        }
//        if (TextUtils.isEmpty(se4)) {
//            e4.requestFocus();
//            e4.setError("Enter the blood group");
//            return;
//        }
//        if (se4.length() < 6) {
//            e4.setError("The password must less than 6 digits.");
//        }
//        if (TextUtils.isEmpty(se5)) {
//            e5.requestFocus();
//            e5.setError("confirm the password");
//            return;
//        }
//        if (!se5.equals(se5)) {
//            e5.requestFocus();
//            e5.setError("Password dosen't match");
//        }
        if (TextUtils.isEmpty(se6)) {
            e6.requestFocus();
            e6.setError("Enter the phone number");
            return;
        }


        StringRequest StringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                         Toast.makeText(Login.this, response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                            checklogin();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //run cheyikkumbo error indo ennu nokkan
                        Toast.makeText(Login.this, String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }

                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", se1);
                params.put("email", se2);
                params.put("password", se3);
                params.put("phonenumber", se6);
                params.put("bloodgroup", se4);



                return params;
            }


        };

        //string reqt ne execute cheyan aanu requestqueue
        Volley volley = null;
        RequestQueue requestQueue = volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }


    private void checklogin() {
        if (status.equals("0")) {
            Toast.makeText(this, "Invalied", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "register successfully", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(Login.this, sign.class);
            startActivity(i);
            finish();
        }

    }

}
