package com.example.bloodbank.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bloodbank.Home;
import com.example.bloodbank.R;
import com.example.bloodbank.SessionManager;
import com.example.bloodbank.config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class profile extends Fragment {

    private EditText name, email, bloodgroup, phnumber, password;
    private Button update;

    private String ppid, pname, pemail, pbloodgroup, pphnumber, ppassword;
    private final String url = config.baseurl + "profileup.php";
    private String status, message;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_profile, container, false);

        name = v.findViewById(R.id.pname1);
        email = v.findViewById(R.id.pemail1);
        bloodgroup = v.findViewById(R.id.pblood1);
        phnumber = v.findViewById(R.id.pphone1);
        password = v.findViewById(R.id.ppass1);
        update = v.findViewById(R.id.pupdate1);

        // Retrieve user details from session
        HashMap<String, String> data = new SessionManager(getActivity()).getUserDetails();

        ppid = data.get("id");
        pname = data.get("name");
        pemail = data.get("email");
        pbloodgroup = data.get("bloodgroup");
        pphnumber = data.get("phonenumber");
        ppassword = data.get("password");

        name.setText(pname);
        email.setText(pemail);
        bloodgroup.setText(pbloodgroup);
        phnumber.setText(pphnumber);
        password.setText(ppassword);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit();
            }
        });
        return v;
    }

    private void submit() {
        String ppname = name.getText().toString();
        String ppemail = email.getText().toString();
        String ppbloodgroup = bloodgroup.getText().toString();
        String ppphnumber = phnumber.getText().toString();
        String pppasword = password.getText().toString();

        if (validateFields(ppname, ppemail, ppbloodgroup, ppphnumber, pppasword)) {
            performUpdate(ppname, ppemail, ppbloodgroup, ppphnumber, pppasword);
        }
    }

    private boolean validateFields(String name, String email, String bloodgroup, String phnumber, String password) {
        if (TextUtils.isEmpty(name)) {
            this.name.requestFocus();
            this.name.setError("Required field");
            return false;
        }
        if (TextUtils.isEmpty(email)) {
            this.email.requestFocus();
            this.email.setError("Required field");
            return false;
        }
        if (TextUtils.isEmpty(bloodgroup)) {
            this.bloodgroup.requestFocus();
            this.bloodgroup.setError("Required field");
            return false;
        }
        if (TextUtils.isEmpty(phnumber)) {
            this.phnumber.requestFocus();
            this.phnumber.setError("Required field");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            this.password.requestFocus();
            this.password.setError("Required field");
            return false;
        }
        return true;
    }

    private void performUpdate(String name, String email, String bloodgroup, String phnumber, String password) {
        StringRequest str = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                handleResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", ppid);
                params.put("name", name);
                params.put("email", email);
                params.put("bloodgroup", bloodgroup);
                params.put("phonenumber", phnumber);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue rq = Volley.newRequestQueue(getActivity());
        rq.add(str);
    }

    private void handleResponse(String response) {
        Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
        try {
            JSONObject json = new JSONObject(response);
            status = json.getString("status");
            message = json.getString("message");
            if ("0".equals(status)) {
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Update successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getActivity(), Home.class));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "Error parsing response", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Clear any bindings if necessary
    }
}
