package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class donate extends AppCompatActivity {
    EditText name, email, bloodgroup, phnumber, place, age,gender,last;
    Button submit,calender;
    RadioGroup regen;





    String sid,sname, semail, sbloodgroup, sphnumber, splace, sage,sgender,slast,status,message;

    String url = config.baseurl + "donate.php";


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate);

        name = findViewById(R.id.dname);
        email = findViewById(R.id.demail);
        bloodgroup= findViewById(R.id.dbloodgroup1);

        phnumber = findViewById(R.id.dphone);
        place = findViewById(R.id.dplace);
        age= findViewById(R.id.dage);
//        gender = findViewById(R.id.dgender);
       // last = findViewById(R.id.ddonate);
        calender=findViewById(R.id.adate);
        submit=findViewById(R.id.sign23);
        regen = findViewById(R.id.gen);




        calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                DatePickerDialog datePicker = new DatePickerDialog(donate.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int day) {
                                calender.setText(day + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                datePicker.show();

            }
        });

        HashMap<String,String> map = new SessionManager(donate.this).getUserDetails();
        sid=map.get("id");
        sname=map.get("name");
        semail=map.get("email");
        sbloodgroup=map.get("bloodgroup");
        sphnumber=map.get("phonenumber");
//        splace=map.get("place");
//        sage=map.get("age");
//        sgender=map.get("gender");
//        slast=map.get("lastdonated");

        name.setText(sname);
        email.setText(semail);
        bloodgroup.setText(sbloodgroup);
        phnumber.setText(sphnumber);
//        place.setText(splace);
//        age.setText(sage);
//        gender.setText(sgender);
//        last.setText(slast);




//        t1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent in = new Intent(Login.this, sign.class);
//                startActivity(in);
//            }
//        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                donate2();
            }
        });
    }

    private void donate2() {

        sname = name.getText().toString();
        semail = email.getText().toString();
//
       sbloodgroup = bloodgroup.getText().toString();

        sphnumber = phnumber.getText().toString();
        splace = place.getText().toString();
        sage=  age.getText().toString();
//        sgender = gender.getText().toString();
        int id=regen.getCheckedRadioButtonId();
        RadioButton radioButton = regen.findViewById(id);
        sgender = radioButton.getText().toString();
        slast   = calender.getText().toString();
        if (TextUtils.isEmpty(sname)) {
            name.requestFocus();
            name.setError("Enter the name");
            return;
        }
        if (TextUtils.isEmpty(semail)) {
            email.requestFocus();
            email.setError("Enter the email");
            return;
        }
        if (TextUtils.isEmpty(sbloodgroup)) {
            bloodgroup.requestFocus();
            bloodgroup.setError("Enter the bloodgroup");
            return;
        }
        if (TextUtils.isEmpty(sphnumber)) {
            phnumber.requestFocus();
            phnumber.setError("Enter the phone number");
            return;
        }

        if (!sphnumber.matches("\\d{10}")) {
            phnumber.requestFocus();
            phnumber.setError("Enter a valid 10-digit phone number");
            return;
        }

        if (TextUtils.isEmpty(splace)) {
            place.requestFocus();
            place.setError("Enter the place");
            return;
        }


        if (TextUtils.isEmpty(sage)) {
            age.requestFocus();
            age.setError("Enter the age");
            return;
        }

        int ageValue;
        try {
            ageValue = Integer.parseInt(sage);
        } catch (NumberFormatException e) {
            age.requestFocus();
            age.setError("Enter a valid number");
            return;
        }

        if (ageValue < 18) {
            age.requestFocus();
            age.setError("Age must be above 18");
            return;
        }

        if (TextUtils.isEmpty(sgender)) {
                    gender.requestFocus();
                    gender.setError("Enter the gender");
                    return;
        }

//        if (TextUtils.isEmpty(slast)) {
//                        last.requestFocus();
//                        last.setError("Enter the last date of blood donation");
//                        return;
//        }

//        if (TextUtils.isEmpty(se5)) {
//            e5.requestFocus();
//            e5.setError("confirm the password");
//            return;
//        }
//        if (!se5.equals(se5)) {
//            e5.requestFocus();
//            e5.setError("Password dosen't match");
//        }



        StringRequest StringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(donate.this, response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                            checklogin();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //run cheyikkumbo error indo ennu nokkan
                        Toast.makeText(donate.this, String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }

                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", sname);
                params.put("email", semail);
                params.put("bloodgroup", sbloodgroup);
                params.put("phnumber", sphnumber);
                params.put("place", splace);
                params.put("age", sage);
                params.put("gender", sgender);
                params.put("lastdonated", slast);
                return params;
            }


        };

        //string reqt ne execute cheyan aanu requestqueue
        Volley volley = null;
        RequestQueue requestQueue = volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }


    private void checklogin() {
        if (status.equals("0")) {
            Toast.makeText(this, "Invalied", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "register successfully", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(donate.this, Home.class);
            startActivity(i);
            finish();
        }

    }

}
