package com.example.bloodbank.ui.home;

//import static androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.Table.map;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.bloodbank.R;
import com.example.bloodbank.SessionManager;
import com.example.bloodbank.book2;
import com.example.bloodbank.campactivity;
import com.example.bloodbank.databinding.FragmentHomeBinding;
import com.example.bloodbank.docupload;
import com.example.bloodbank.donate;
import com.example.bloodbank.donatelistactivity;
import com.example.bloodbank.location;
import com.example.bloodbank.nearby;

import java.util.HashMap;

public class HomeFragment extends Fragment {

    CardView c,c2,c3,c4;
    String sid,sname;
    TextView name;
//    Button b1;


    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        c=root.findViewById(R.id.donate3);
        c2=root.findViewById(R.id.receive3);
        c3=root.findViewById(R.id.locate);
        c4=root.findViewById(R.id.camp_register);
        name=root.findViewById(R.id.name);
//        c4=root.findViewById(R.id.receive4);
        HashMap<String,String> data=new SessionManager(getActivity()).getUserDetails();
        sid=data.get("id");
//        b1=root.findViewById(R.id.upload);
        sname=data.get("name");
        name.setText(sname);



        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getActivity(), donate.class);
                startActivity(in);
            }
        });
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent rn =new Intent(getActivity(), donatelistactivity.class);
                startActivity(rn);
            }
        });
        c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ln =new Intent(getActivity(), location.class);
                startActivity(ln);
            }
        });
        c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent zn =new Intent(getActivity(), book2.class);
                startActivity(zn);
            }
        });


//        c4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent jn=new Intent(getActivity(), nearby.class);
//                startActivity(jn);
//            }
//        });
//        b1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent jn=new Intent(getActivity(), docupload.class);
//                startActivity(jn);
//            }
//        });


//        final TextView textView = binding.textHome;
//        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
       return root;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}