package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.bloodbank.config;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class booking extends AppCompatActivity {
    EditText time2;
    EditText dh, dd, patientname;
    TextView doctorname,phone;
    Button c;
    Calendar xtime;
    Button b;

    String url = config.baseurl + "appointment.php";
    String doctor, h, phn, patient, ca, ti, status, message, id, id1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
        xtime = Calendar.getInstance();
        doctorname = findViewById(R.id.td);
        patientname = findViewById(R.id.td3);
//        c = findViewById(R.id.td41);
//        time2 = findViewById(R.id.td516);
        phone=findViewById(R.id.td2);
        b = findViewById(R.id.td6);


        Intent intent = getIntent();
        doctor = intent.getStringExtra("name");
        doctorname.setText(doctor);

        HashMap<String, String> map = new SessionManager(booking.this).getUserDetails();
        id = map.get("id");
        patient = map.get("name");
        patientname.setText(patient);
        phn=map.get("phonenumber");
        phone.setText(phn);



//        c.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                final Calendar cldr = Calendar.getInstance();
//                int day = cldr.get(Calendar.DAY_OF_MONTH);
//                int month = cldr.get(Calendar.MONTH);
//                int year = cldr.get(Calendar.YEAR);
//                DatePickerDialog datePicker = new DatePickerDialog(booking.this,
//                        new DatePickerDialog.OnDateSetListener() {
//                            @Override
//                            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int day) {
//                                c.setText(day + "/" + (monthOfYear + 1) + "/" + year);
//                            }
//                        }, year, month, day);
//                datePicker.show();
//
//            }
//        });
//        time2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int hour = xtime.get(Calendar.HOUR_OF_DAY);
//                int minute = xtime.get(Calendar.MINUTE);
//                TimePickerDialog timePickerDialog=  new TimePickerDialog(booking.this,
//                        new TimePickerDialog.OnTimeSetListener() {
//                            @Override
//                            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
//
//                                Time time = new Time(hour, minute, 0);
//
//                                //little h uses 12 hour format and big H uses 24 hour format
//                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("h:mm");
//
//                                //format takes in a Date, and Time is a sublcass of Date
//                                String s = simpleDateFormat.format(time);
//                                time2.setText(s);
//                            }
//                        }, hour, minute, false);
//                timePickerDialog.setTitle("select time");
//                timePickerDialog.show();
//            }
//        });


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donatepeoples1();
            }
        });


    }

    private void donatepeoples1() {

        doctor = doctorname.getText().toString();

        patient = patientname.getText().toString();

        phn= phone.getText().toString();
//
//        ca = c.getText().toString();
//
//        ti = time2.getText().toString();


//        if (TextUtils.isEmpty(dname)) {
//            donorname.requestFocus();
//            donorname.setError("Enter name");
//            return;
//        }
//
//        if (TextUtils.isEmpty(daddress)) {
//            donoradde.requestFocus();
//            donoradde.setError("Enter address");
//            return;
//        }
//        if (TextUtils.isEmpty(dadis)) {
//            donordis.requestFocus();
//            donordis.setError("Enter address");
//            return;
//        }
//
//        if (TextUtils.isEmpty(demail)) {
//            donormail.requestFocus();
//            donormail.setError("Enter email");
//            return;
//        }
//        if (TextUtils.isEmpty(dphonenumber)) {
//            donorphn.requestFocus();
//            donorphn.setError("Enter phone number");
//            return;
//        }

        StringRequest StringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(booking.this, response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                            checklogin();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(booking.this, String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }

                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("campname", doctor);
                params.put("name", patient);
                params.put("phonenumber", phn);
//                params.put("date", ca);
//                params.put("time", ti);

                return params;
            }


        };
        Volley volley = null;
        RequestQueue requestQueue = volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }


    private void checklogin() {
        if (status.equals("0")){
            Toast.makeText(this, "Invalied", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "sumitted successfully", Toast.LENGTH_SHORT).show();
           new notifi(booking.this).showNotification(booking.this,doctor,"Camp booking succesful. Thank You for your service... ");

            Intent i =new Intent(booking.this,Home.class);

//
//            i.putExtra("id",id);
//            //   i.putExtra("doctorname",n);
//            i.putExtra("patientname",p);
//            i.putExtra("date",ca);
//            i.putExtra("time",ti);

            startActivity(i);
            finish();
        }
    }
}




