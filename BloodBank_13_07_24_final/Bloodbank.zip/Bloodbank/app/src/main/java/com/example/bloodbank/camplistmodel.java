package com.example.bloodbank;

public class camplistmodel {
    String id,campname,name,phonenumber;


    public camplistmodel(String id, String campname, String name, String phonenumber) {
        this.id = id;
        this.campname = campname;
        this.name = name;
        this.phonenumber = phonenumber;
    }

    public String getId() {
        return id;
    }

    public String getCampname() {
        return campname;
    }

    public String getName() {
        return name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }
}
