package com.example.bloodbank;

import static androidx.core.content.ContextCompat.startActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

//import com.mashood.kaudisorders.R;
//import com.mashood.kaudisorders.disorder.DisorderListActivity;
//import com.squareup.picasso.Picasso;

//import com.example.wecan.ui.dashboard.DashboardFragment;

import java.util.ArrayList;

public class campadpater extends RecyclerView.Adapter<campadpater.MyViewHolder> {





    private LayoutInflater inflater;
    private ArrayList<campmodel> dataModelArrayList;
    private Context c;




    public campadpater(Context ctx, ArrayList<campmodel> dataModelArrayList) {

        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.camp, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }




    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.campname.setText(""+dataModelArrayList.get(position).getCampname());
        holder.campplace.setText("Place:"+dataModelArrayList.get(position).getCampplace());
        holder.campphone.setText(" Contact:  "+dataModelArrayList.get(position).getCampphone());
        holder.campdate.setText("Date:  "+dataModelArrayList.get(position).getCampdate());
        holder.camptime.setText("Time:  "+dataModelArrayList.get(position).getCamptime());

//        holder.age.setText("Age:  "+dataModelArrayList.get(position).getEmail());
//        holder.gender.setText("Gender:  "+dataModelArrayList.get(position).getGender());
//        holder.lastdonated.setText("LastDonated:  "+dataModelArrayList.get(position).getLastdonated());



        //call function
        holder.campphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(dataModelArrayList.get(position).getCampphone());
            }

            private void call(String contactnumber) {
                Intent intent=new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" +contactnumber));
                c.startActivity(intent);
            }
        });

        //button click cheyumbo data kittan
//
        holder.b21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(c, booking.class);

                intent.putExtra("name",dataModelArrayList.get(position).getCampname());

                c.startActivity(intent);

//                        if (!dataModelArrayList.get(position).getImage().equals("")) {
//            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
            }

        });
//

//        holder.cardView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                Intent intent = new Intent(c, donatefullactivity.class);
//                intent.putExtra("name",dataModelArrayList.get(position).getName());
//
//
//                c.startActivity(intent);
//
////                        if (!dataModelArrayList.get(position).getImage().equals("")) {
////            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
//            }
////
//        });

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(c, campfullactivity.class);
                intent.putExtra("name",dataModelArrayList.get(position).getCampname());
                intent.putExtra("campdetails", dataModelArrayList.get(position).getCampdetails());
                c.startActivity(intent);

//                        if (!dataModelArrayList.get(position).getImage().equals("")) {
//            Picasso.get.load(config.imgurl+dataModelArrayList.get(position).getImage()).into(holder.image);
            }

        });


//        sms nte code
//




//      holder.cardView.setOnClickListener(new View.OnClickListener() {
//           @Override
//           public void onClick(View view) {
//               BookingDataModel p = dataModelArrayList.get(position);
//             String crop = p.getBloodgp();
//           //    String img = p.getImage();
//              Intent i = new Intent(c, Bookingdonorslist.class);
//               i.putExtra("crop", crop);
//               c.startActivity(i);
//            }
//       });

    }


    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }


    public void filterList(ArrayList<campmodel> filteredSongs) {
        this.dataModelArrayList = filteredSongs;
        notifyDataSetChanged();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {


        CardView cardView;
        TextView campname,campplace,campdate,camptime,campphone;

         Button b21;
        String id,cname;


        public MyViewHolder(View itemView) {
            super(itemView);
            cardView=itemView.findViewById(R.id.card_view);
            campname = itemView.findViewById(R.id.text_name);
            campplace=itemView.findViewById(R.id.text_place);
            campphone = itemView.findViewById(R.id.text_phone);
            campdate = itemView.findViewById(R.id.text_date);
            camptime = itemView.findViewById(R.id.text_time);
            b21 = itemView.findViewById(R.id.button_book_now);


//            age = itemView.findViewById(R.id.age2);
//            gender = itemView.findViewById(R.id.gender2);
//            lastdonated =itemView.findViewById(R.id.last2);

//            edit.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Intent in=new Intent(c, Doctorsbookingform.class);
//                    in.putExtra("id",id);
//                    in.putExtra("name",cname);
//
//                }
//            });



        }

    }
}


