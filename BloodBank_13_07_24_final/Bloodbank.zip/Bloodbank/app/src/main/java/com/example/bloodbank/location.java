package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class location extends AppCompatActivity {

    WebView w;


    @SuppressLint("MissingInflatedId")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        w = findViewById(R.id.location);

        WebSettings webSettings=w.getSettings();
        webSettings.setJavaScriptEnabled( true );
        w.loadUrl("https://www.google.com/maps/search/blood+bank+near+by+thrissur/@10.1416493,76.2968022,9.72z?entry=ttu");
        w.setWebViewClient( new WebViewClient() );
    }
}