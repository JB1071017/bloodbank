package com.example.bloodbank;

public class campmodel {


    String id,campname,campplace,campdate,camptime,campphone,campdetails;

    public campmodel(String id, String campname, String campplace, String campdate, String camptime, String campphone, String campdetails) {
        this.id = id;
        this.campname = campname;
        this.campplace = campplace;
        this.campdate = campdate;
        this.camptime = camptime;
        this.campphone = campphone;
        this.campdetails = campdetails;
    }

    public String getId() {
        return id;
    }

    public String getCampname() {
        return campname;
    }

    public String getCampplace() {
        return campplace;
    }

    public String getCampdate() {
        return campdate;
    }

    public String getCamptime() {
        return camptime;
    }

    public String getCampphone() {
        return campphone;
    }

    public String getCampdetails() {
        return campdetails;
    }
}


